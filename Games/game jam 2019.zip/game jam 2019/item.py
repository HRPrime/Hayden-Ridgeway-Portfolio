#pickup class

import globalVars
from math3d import *
import pygame
import math


class Item():
    def __init__(self,x,y):
        self.pos = vec2(x,y)
        self.magic = pygame.image.load("assets\magic.png")


    def draw(self):
        globalVars.Screen.DS.blit(self.magic,(self.pos[0]-25,self.pos[1]-25))


    def dist(self,other,c):
        """Must pass in 'other' as vec2 and 'c' as the distance wanted to make true"""
        if isinstance(other,vec2) != True:
            raise TypeError("Dist requires a vec2 for parameter 2")
        if isinstance(c,int) != True:
            raise TypeError("Dist requires an int for parameter 3")

        #print(math.sqrt((other[0] - self.pos[0])**2 + (other[1] - self.pos[1])**2))
        
        return c >= math.sqrt((other[0] - self.pos[0])**2 + (other[1] - self.pos[1])**2)
