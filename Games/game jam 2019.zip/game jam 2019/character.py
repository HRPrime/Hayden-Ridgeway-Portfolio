#Character class

from math3d import *
import pygame
import random
import globalVars
import bullet
import time


class character():
    def __init__(self,x,y,version,moving):
        self.pos = vec2(x,y)
        self.speed = 5
        self.x = self.pos[0]
        self.y = self.pos[1]
        self.sprite = None
        self.color = (255,255,255)
        self.FACING = 0 #can face 0 = left or 1 = right or 2 = up or 3 = down
        self.version = version

        #for only player
        self.start_time = time.time()
        self.limitshot = 1
        self.gun = False
        if version == 0:
            self.cat_1 = pygame.image.load("assets\PC_Cat_o1[1].png")
            self.cat_2 = pygame.image.load("assets\PC_Cat_b[2].png")
            self.cat_3 = pygame.image.load("assets\PC_Cat_o2[2].png")
        self.animation_time = 0
        self.animation_start = time.time()
        self.RUN = False
        self.doorlimit = 2
        self.door_start = time.time()
        self.no = pygame.image.load("assets\ope.png")
        self.get_corrupt = pygame.image.load("assets\corruptor_pickup.png")
        self.no_weapon_start = time.time()
        self.find_weapon_start = time.time()
        self.find_weapon_passed_time = time.time() - self.find_weapon_start
        
        #for only npc/fake_player
        self.corruption = None
        self.startx = x
        self.starty = y
        self.fake_speed = 5
        self.limitcorrupt = 0.1
        if version == 1:
            self.goat_NPC_1 = pygame.image.load("assets\goat1.png")
            self.goat_NPC_1_flip = pygame.image.load("assets\goat1_flip.png")
        if version == 2:
            self.goat_NPC_2 = pygame.image.load("assets\goat2.png")
            self.goat_NPC_2_flip = pygame.image.load("assets\goat2_flip.png")
        self.ismoving = moving


    def draw(self):

        if globalVars.screen.KP[pygame.K_d] == False and globalVars.screen.KP[pygame.K_w] == False and globalVars.screen.KP[pygame.K_a] == False and globalVars.screen.KP[pygame.K_s] == False:
            if self.animation_time_passed >= 0 and self.animation_time_passed < 0.5:
                globalVars.Screen.DS.blit(self.cat_1,(self.pos[0]-50,self.pos[1]-50))
            elif self.animation_time_passed >= 0.5 and self.animation_time_passed < 1:
                globalVars.Screen.DS.blit(self.cat_2,(self.pos[0]-50,self.pos[1]-50))
            elif self.animation_time_passed >= 1 and self.animation_time_passed < 1.5:
                globalVars.Screen.DS.blit(self.cat_3,(self.pos[0]-50,self.pos[1]-50))
                self.animation_start = time.time()
        elif  globalVars.screen.KP[pygame.K_d] == True or globalVars.screen.KP[pygame.K_w] == True or globalVars.screen.KP[pygame.K_a] == True or globalVars.screen.KP[pygame.K_s] == True:
            globalVars.Screen.DS.blit(self.cat_1,(self.pos[0]-50,self.pos[1]-50))

        if self.find_weapon_passed_time < 5 and self.gun == True:
            globalVars.Screen.DS.blit(self.get_corrupt,(self.pos[0]-250,self.pos[1]-90))
        ##pygame.draw.circle(globalVars.Screen.DS,self.color,(int(self.pos[0]),int(self.pos[1])),10)
        
##        if self.FACING == 0:
##            pygame.draw.circle(globalVars.Screen.DS,(0,0,0),(int(self.pos[0]-5),int(self.pos[1])),5)
##
##        elif self.FACING == 1:
##            pygame.draw.circle(globalVars.Screen.DS,(0,0,0),(int(self.pos[0]+5),int(self.pos[1])),5)

    def draw_npc(self):
        if self.corruption != 2:
            if self.version == 1:
                if self.FACING == 0:
                    globalVars.Screen.DS.blit(self.goat_NPC_1_flip,(self.pos[0]-50,self.pos[1]-50))
                elif self.FACING == 1:
                    globalVars.Screen.DS.blit(self.goat_NPC_1,(self.pos[0]-50,self.pos[1]-50))
            if self.version == 2:
                if self.FACING == 0:
                    globalVars.Screen.DS.blit(self.goat_NPC_2_flip,(self.pos[0]-50,self.pos[1]-50))
                elif self.FACING == 1:
                    globalVars.Screen.DS.blit(self.goat_NPC_2,(self.pos[0]-50,self.pos[1]-50))
        
    def update(self):
        """only for player character"""
        if globalVars.screen.KP[pygame.K_d] == True:
            self.pos[0] += self.speed
            self.FACING = 1
            self.animation_start = time.time()
        elif globalVars.screen.KP[pygame.K_a] == True:
            self.pos[0] -= self.speed
            self.FACING = 0
            self.animation_start = time.time()
        if globalVars.screen.KP[pygame.K_w] == True:
            self.pos[1] -= self.speed
            self.FACING = 2
            self.animation_start = time.time()
        elif globalVars.screen.KP[pygame.K_s] == True:
            self.pos[1] += self.speed
            self.FACING = 3
            self.animation_start = time.time()

        if globalVars.screen.KP[pygame.K_LSHIFT] == True and self.RUN == False:
            self.speed += 10
            self.RUN = True

        if globalVars.screen.KP[pygame.K_LSHIFT] == False and self.RUN == True:
            self.speed -= 10
            self.RUN = False
        if globalVars.start_map.place == 0:
            door_time_passed = time.time() - self.door_start
        if globalVars.screen.KP[pygame.K_f] == True and globalVars.house2_door.dist(vec2(self.pos[0]-200,self.pos[1]-250),50) == True and self.doorlimit <= door_time_passed:
            globalVars.start_map.place = 1
            self.pos[0] = 900
            self.pos[1] = 390
            self.door_start = time.time()

        if globalVars.start_map.place == 1:
            if globalVars.screen.KP[pygame.K_f] == True and globalVars.inhouse2_door.dist(self.pos,100) == True:
                globalVars.start_map.place = 0
                self.pos[0] = globalVars.house2.pos[0]+200
                self.pos[1] = globalVars.house2.pos[1]+250

            if self.pos[0] > 1030:
                self.pos[0] = 1030
            elif self.pos[0] < 690:
                self.pos[0] = 690
            if self.pos[1] > 590:
                self.pos[1] = 590
            elif self.pos[1] < 300:
                self.pos[1] = 300

        if self.pos[0] > 1930:
            self.pos[0] = -10
        elif self.pos[0] < -5:
            self.pos[0] = 1930
        if self.pos[1] > 1090:
            self.pos[1] = -10
        elif self.pos[1] < -5:
            self.pos[1] = 1090

        self.time_passed = time.time() - self.start_time
        self.animation_time_passed = time.time() - self.animation_start

        if globalVars.magic_weapon.dist(vec2(self.pos[0]+50,self.pos[1]+50),50) == True and self.gun == False and globalVars.start_map.place == 1:
            self.gun = True

        if self.gun == False:
            self.find_weapon_start = time.time()

        self.find_weapon_passed_time = time.time() - self.find_weapon_start

    def update_npc(self,version):
        """randomized simple AI for non-player characters"""
        pass
            

    def update_fake_player(self,version):
        """randomized sinple AI for other MMO players"""
        if self.corruption == None or self.corruption != 1 or self.corruption != 5:
            if self.ismoving == True:
                if version == 0:
                    self.FACING = 1
                    self.pos[0] += self.fake_speed
                    if self.pos[0] >= 2000:
                        self.pos[0] = -10
                elif version == 1:
                    self.pos[1] += self.fake_speed
                    if self.pos[1] >= 2000:
                        self.pos[1] = -10

                elif version == 2:
                    self.pos[0] -= self.fake_speed
                    if self.pos[0] <= -10:
                        self.pos[0] = 2000

        if self.corruption == 0 and self.ismoving == True:
            """speed up"""
            self.fake_speed += 10
            self.corruption = None

        elif self.corruption == 1 and self.ismoving == True:
            if globalVars.screen.KP[pygame.K_d] == True:
                self.pos[0] += self.speed
                self.FACING = 1
            elif globalVars.screen.KP[pygame.K_a] == True:
                self.pos[0] -= self.speed
                self.FACING = 0
            if globalVars.screen.KP[pygame.K_w] == True:
                self.pos[1] -= self.speed
            elif globalVars.screen.KP[pygame.K_s] == True:
                self.pos[1] += self.speed
                
        if self.corruption == 2:
            """asset randomization"""
            r1 = pygame.image.load("assets\PC_Cat_b[2].png")
            r2 = pygame.image.load("assets\goat1.png")
            r3 = pygame.image.load("assets\goat2_flip.png")
            r4 = pygame.image.load("assets\house_with_door.png")
            r5 = pygame.image.load("assets\PC_Cat_o2[2].png")
            random_asset = random.randint(0,5)
            if random_asset == 0:
                globalVars.Screen.DS.blit(r1,self.pos)
            elif random_asset == 1:
                globalVars.Screen.DS.blit(r2,self.pos)
            elif random_asset == 2:
                globalVars.Screen.DS.blit(r3,self.pos)
            elif random_asset == 3:
                globalVars.Screen.DS.blit(r4,self.pos)
            elif random_asset == 4:
                globalVars.Screen.DS.blit(r5,self.pos)
                
        if self.corruption == 3:
            """random location once"""
            self.pos[0] = random.randint(0,1980)
            self.pos[1] = random.randint(0,1080)
            self.corruption = None

        if self.corruption == 4:
            """random location teleport"""
            if self.limitcorrupt < self.time_passed:
                self.pos[0] = random.randint(0,1980)
                self.pos[1] = random.randint(0,1080)
                self.start_time = time.time()

        if self.corruption == 5:
            """SPEEEEEN"""
            if self.limitcorrupt < self.time_passed:
                self.FACING = random.randint(0,1)
            
        self.time_passed = time.time() - self.start_time
        
    def dist(self,other,c):
        """Must pass in 'other' as vec2 and 'c' as the distance wanted to make true"""
        if isinstance(other,vec2) != True:
            raise TypeError("Dist requires a vec2 for parameter 2")
        if isinstance(c,int) != True:
            raise TypeError("Dist requires an int for parameter 3")
        
        return c >= ((self.pos[0] - other[0])**2 + (self.pos[1] - other[1])**2)**0.5

    def talk(self):
        """randomized dialogue for npc"""
        pass

    def attack(self):
        if globalVars.screen.KP[pygame.K_SPACE] == True and self.limitshot < self.time_passed:
            if self.gun == True:
                globalVars.bullets.append(bullet.Bullet(self.pos[0],self.pos[1],self.FACING))
                self.start_time = time.time()
            elif self.gun == False:
                globalVars.Screen.DS.blit(self.no,(self.pos[0]-170,self.pos[1]-90))
                

    def corrupt(self):
        """random corruption options when used with 'The Corruptor' weapon"""
        if self.corruption == None:
            if self.ismoving == True:
                self.corruption = random.randint(0,5)

            else:
                self.corruption = random.randint(2,5)
    
