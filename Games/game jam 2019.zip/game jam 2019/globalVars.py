#global varables to be called

from screen import *
from character import *
from location import *
from house import *
from door import *
from item import *

bullets = []

screen = Screen()
player = character(500,500,0,True)

magic_weapon = Item(718,440)
                    
test1 = character(600,600,1,True)
test2 = character(400,400,1,True)
test3 = character(1200,400,2,True)
test4 = character(1400,100,1,False)
test5 = character(700,1000,2,False)


start_map = Location(0)

house1 = House(0,0,0)
house2 = House(500,0,1)
house3 = House(0,500,0)
house4 = House(1000,0,0)
house5 = House(1500,0,0)
house6 = House(500,500,0)
house7 = House(1000,500,0)
house8 = House(1500,500,0)

house2_door = Door(house2.pos[0],house2.pos[1])
inhouse2_door = Door(1030,380)

