#house

import pygame
import globalVars
import random
from math3d import *
import time

class House():
    def __init__(self,x,y,version):
        self.pos = vec2(x,y)
        self.version = version #multiple houses, some not interactable
        self.house_with_door = pygame.image.load("assets\house_with_door.png")
        self.house = pygame.image.load("assets\house.png")

        #for corruptions
        self.start_time = time.time()
        self.corruption = None
        self.limitcorrupt = 1
        self.speed = 10
        

    def draw(self):
        if self.corruption != 2:
            if self.version == 0:
                globalVars.Screen.DS.blit(self.house,self.pos)
            elif self.version == 1:
                globalVars.Screen.DS.blit(self.house_with_door,self.pos)

    def corrupt(self):
        if self.corruption == None:
            self.corruption = random.randint(0,4)
            

    def update(self):
        version = None
        if self.corruption == 0:
            version = random.randint(0,2)
            if version == 0:
                self.FACING = 1
                self.pos[0] += self.speed
                if self.pos[0] >= 2000:
                    self.pos[0] = -10
            elif version == 1:
                self.pos[1] += self.speed
                if self.pos[1] >= 2000:
                    self.pos[1] = -10

            elif version == 2:
                self.pos[0] -= self.speed
                if self.pos[0] <= -10:
                    self.pos[0] = 2000

        elif self.corruption == 1:
            if globalVars.screen.KP[pygame.K_d] == True:
                self.pos[0] += self.speed
                self.FACING = 1
            elif globalVars.screen.KP[pygame.K_a] == True:
                self.pos[0] -= self.speed
                self.FACING = 0
            if globalVars.screen.KP[pygame.K_w] == True:
                self.pos[1] -= self.speed
            elif globalVars.screen.KP[pygame.K_s] == True:
                self.pos[1] += self.speed
                
        if self.corruption == 2:
            """asset randomization"""
            r1 = pygame.image.load("assets\PC_Cat_b[2].png")
            r2 = pygame.image.load("assets\goat1.png")
            r3 = pygame.image.load("assets\goat2_flip.png")
            r4 = pygame.image.load("assets\house_with_door.png")
            r5 = pygame.image.load("assets\PC_Cat_o2[2].png")
            random_asset = random.randint(0,5)
            if random_asset == 0:
                globalVars.Screen.DS.blit(r1,(self.pos[0]+150,self.pos[1]+150))
            elif random_asset == 1:
                globalVars.Screen.DS.blit(r2,(self.pos[0]+150,self.pos[1]+150))
            elif random_asset == 2:
                globalVars.Screen.DS.blit(r3,(self.pos[0]+150,self.pos[1]+150))
            elif random_asset == 3:
                globalVars.Screen.DS.blit(r4,self.pos)
            elif random_asset == 4:
                globalVars.Screen.DS.blit(r5,(self.pos[0]+150,self.pos[1]+150))

        if self.corruption == 3:
            """random location once"""
            self.pos[0] = random.randint(0,1980)
            self.pos[1] = random.randint(0,1080)
            self.corruption = None

        if self.corruption == 4:
            """random location teleport"""
            if self.limitcorrupt < self.time_passed:
                self.pos[0] = random.randint(0,1980)
                self.pos[1] = random.randint(0,1080)
                self.start_time = time.time()
            
        self.time_passed = time.time() - self.start_time
    def dist(self,other,c):
        """Must pass in 'other' as vec2 and 'c' as the distance wanted to make true"""
        if isinstance(other,vec2) != True:
            raise TypeError("Dist requires a vec2 for parameter 2")
        if isinstance(c,int) != True:
            raise TypeError("Dist requires an int for parameter 3")
        
        return c >= ((self.pos[0] - other[0])**2 + (self.pos[1] - other[1])**2)**0.5
