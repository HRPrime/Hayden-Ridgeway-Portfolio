#door

from math3d import *
import pygame
import globalVars

class Door():
    def __init__(self,x,y):
        self.pos = vec2(x,y)
        self.corruption = None
        print(self.pos)
        print(globalVars.house2.pos)

    def draw(self):
        pygame.draw.rect(globalVars.Screen.DS,(255,0,0),((self.pos[0]+200),(self.pos[1]+250),20,50))

    def update(self):
        pass

    def corrupt(self):
        pass

        #missing model
        #location error
        #door starts talking
        #random x/y

    def dist(self,other,c):
        """Must pass in 'other' as vec2 and 'c' as the distance wanted to make true"""
        if isinstance(other,vec2) != True:
            raise TypeError("Dist requires a vec2 for parameter 2")
        if isinstance(c,int) != True:
            raise TypeError("Dist requires an int for parameter 3")

        print(((self.pos[0] - other[0])**2 + (self.pos[1] - other[1])**2)**0.5)
        
        return c >= ((self.pos[0] - other[0])**2 + (self.pos[1] - other[1])**2)**0.5
        
