#main loop

import globalVars
from math3d import *


while globalVars.screen.running == True:

    if globalVars.player.pos[1] < 800 and globalVars.player.pos[1] >= 500:
        globalVars.player.update()
        globalVars.player.draw()
        globalVars.player.attack()

    if globalVars.player.pos[1] < 290:
        globalVars.player.update()
        globalVars.player.draw()
        globalVars.player.attack()

    for b in globalVars.bullets:
        b.draw()
        b.update()
        if b.isdead(0) == True:
            globalVars.bullets.remove(b)
        if b.dist(globalVars.test1.pos,50):
            globalVars.test1.corrupt()
            globalVars.bullets.remove(b)
        if b.dist(globalVars.test2.pos,50):
            globalVars.test2.corrupt()
            globalVars.bullets.remove(b)
        if b.dist(globalVars.test3.pos,50):
            globalVars.test3.corrupt()
            globalVars.bullets.remove(b)
        if b.dist(globalVars.test4.pos,50):
            globalVars.test4.corrupt()
            globalVars.bullets.remove(b)
        if b.dist(globalVars.test5.pos,50):
            globalVars.test5.corrupt()
            globalVars.bullets.remove(b)
        if b.dist(vec2(globalVars.house1.pos[0]+150,globalVars.house1.pos[1]+150),100):
            globalVars.house1.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house2.pos[0]+150,globalVars.house2.pos[1]+150),100):
            globalVars.house2.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house3.pos[0]+150,globalVars.house3.pos[1]+150),100):
            globalVars.house3.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house4.pos[0]+150,globalVars.house4.pos[1]+150),100):
            globalVars.house4.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house5.pos[0]+150,globalVars.house5.pos[1]+150),100):
            globalVars.house5.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house6.pos[0]+150,globalVars.house6.pos[1]+150),100):
            globalVars.house6.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house7.pos[0]+150,globalVars.house7.pos[1]+150),100):
            globalVars.house7.corrupt()
            globalVars.bullets.remove(b)
        elif b.dist(vec2(globalVars.house8.pos[0]+150,globalVars.house8.pos[1]+150),100):
            globalVars.house8.corrupt()
            globalVars.bullets.remove(b)

    if globalVars.start_map.place == 0:        
        globalVars.test1.draw_npc()
        globalVars.test1.update_fake_player(0)

        globalVars.test2.draw_npc()
        globalVars.test2.update_fake_player(1)

        globalVars.test3.draw_npc()
        globalVars.test3.update_fake_player(2)

        globalVars.test4.draw_npc()
        globalVars.test4.update_fake_player(0)

        globalVars.test5.draw_npc()
        globalVars.test5.update_fake_player(0)

        globalVars.house1.draw()
        globalVars.house2.draw()
        #globalVars.house2_door.draw()
        globalVars.house3.draw()
        globalVars.house4.draw()
        globalVars.house5.draw()
        globalVars.house6.draw()
        globalVars.house7.draw()
        globalVars.house8.draw()
        globalVars.house1.update()
        globalVars.house2.update()
        globalVars.house3.update()
        globalVars.house4.update()
        globalVars.house5.update()
        globalVars.house6.update()
        globalVars.house7.update()
        globalVars.house8.update()

    if globalVars.start_map.place == 1:
        if globalVars.player.gun == False:
            globalVars.magic_weapon.draw()

    if globalVars.player.pos[1] < 500 and globalVars.player.pos[1] >= 290:
        globalVars.player.update()
        globalVars.player.draw()
        globalVars.player.attack()

    if globalVars.player.pos[1] >= 800:
        globalVars.player.update()
        globalVars.player.draw()
        globalVars.player.attack()
    
    globalVars.screen.keypress()
    globalVars.screen.update()

    globalVars.start_map.draw()
    
    #globalVars.screen.draw()


globalVars.screen.turnoff()
