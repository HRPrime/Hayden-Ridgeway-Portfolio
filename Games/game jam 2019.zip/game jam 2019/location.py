#rooms
from math3d import *
import pygame
import random
import globalVars

class Location():
    def __init__(self,starting):
        #self.place for location of screen. 0 = starting, 1 = house
        self.place = starting

        #for self.place = 1
        self.sand = pygame.image.load("assets\sand.png")
        self.inhouse = pygame.image.load("assets\inhouse.png")

        #for self.place = 2
        self.wall_color = (0,0,0)

        self.track1 = pygame.mixer.music.load("assets\dreamscape.mp3")
        
        self.playonce = True

    def draw(self):
        if self.place == 0:
            #pygame.draw.rect(globalVars.Screen.DS,(210,180,140),(0,0,2000,1500))
            globalVars.Screen.DS.blit(self.sand,(0,0))

        elif self.place == 1:
            globalVars.Screen.DS.fill((0,0,0))
            globalVars.Screen.DS.blit(self.inhouse,(660,240))
            pygame.draw.rect(globalVars.Screen.DS,self.wall_color,(660,240,400,400),3)
            pygame.draw.rect(globalVars.Screen.DS,self.wall_color,(1050,380,10,40))

        #not really drawing but whatever
        if globalVars.player.gun == False and self.playonce == True:
            self.playonce = False
            pygame.mixer.music.play()

    def update(self):
        pass

