#bullets

from math3d import *
import globalVars
import pygame
import math

class Bullet():
    def __init__(self,x,y,FACING):
        self.pos = vec2(x,y)
        self.speed = 30
        self.FACING = FACING
        self.magic = pygame.image.load("assets\magic.png")

    def draw(self):
        #pygame.draw.circle(globalVars.Screen.DS,(255,255,255),(int(self.pos[0]),int(self.pos[1])),2)
        globalVars.Screen.DS.blit(self.magic,(self.pos[0]-25,self.pos[1]-25))
        
    def update(self):
        if self.FACING == 0:
            self.pos[0] -= self.speed
        elif self.FACING == 1:
            self.pos[0] += self.speed
        elif self.FACING == 2:
            self.pos[1] -= self.speed
        elif self.FACING == 3:
            self.pos[1] += self.speed

    def dist(self,other,c):
        """Must pass in 'other' as vec2 and 'c' as the distance wanted to make true"""
        if isinstance(other,vec2) != True:
            raise TypeError("Dist requires a vec2 for parameter 2")
        if isinstance(c,int) != True:
            raise TypeError("Dist requires an int for parameter 3")
        
        return c >= math.sqrt((other[0] - self.pos[0])**2 + (other[1] - self.pos[1])**2)

    def isdead(self,override):
        if override == 1:
            return True
        else:
            if self.pos[0] >= 2000:
                return True
            elif self.pos[0] <= -10:
                return True
            elif self.pos[1] >= 2000:
                return True
            elif self.pos[1] <= -10:
                return True

        return False
    
    
