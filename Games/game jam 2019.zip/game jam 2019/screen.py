#pygame stuff
import pygame
import random
from math3d import *
import time

class Screen():
    pygame.init()
    pygame.display.init()
    pygame.mixer.init()
    pygame.font.init()
    pygame.mixer.music.set_volume(0.5)
    DS = None
    clock = pygame.time.Clock()
    start_time = time.time()
    
    def __init__(self):
        if Screen.DS == None:
            Screen.DS = pygame.display.set_mode((1920,1080),pygame.FULLSCREEN)
        self.running = True

        self.mpx,self.mpy = pygame.mouse.get_pos()
        self.MP = vec2(self.mpx,self.mpy)
        self.KP = pygame.key.get_pressed()

        self.time_passed = time.time() - Screen.start_time

    def update(self):
        Screen.clock.tick(60)
        self.time_passed = time.time() - Screen.start_time
        self.mpx,self.mpy = pygame.mouse.get_pos()
        self.MP = vec2(self.mpx,self.mpy)
        self.KP = pygame.key.get_pressed()
        
        pygame.display.update()
        pygame.event.pump()

    def draw(self):
        Screen.DS.fill((0,0,0))

    def keypress(self):
        if self.KP[pygame.K_ESCAPE] == True:
              self.running = False

    def turnoff(self):
        if self.running == False:
            pygame.mixer.quit()
            pygame.display.quit()
