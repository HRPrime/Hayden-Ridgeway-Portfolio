import pygame
import map as map
from Running import *


me_vs_jason_2 = "still"
me_vs_jason_3 = "still_2"
frame_counter = 0
frame_counter_a = 0
window_width = 800
window_height = 600
pygame.init()
window = pygame.display.set_mode((window_width, window_height))#pygame.FULLSCREEN)
M = map.Map("classroom.txt")
calc = keys()
player_x = 300
player_y = 300
clock = pygame.time.Clock()
checks = 0
keylist = []
me_vs_jason = pygame.image.load("scene\\me_vs_jason.png")
me_vs_jason_4 = pygame.image.load("scene\\me_vs_jason_2.png")
jasonx_value=0
var2 = False
gamestate = 0

while gamestate == 0:
    clock.tick(60)
    event = pygame.event.poll()
    pygame.event.pump()
    if event.type == pygame.KEYDOWN:
        keylist.append(event.key)
    var = calc.checkpat(window, checks, keylist,var2)
    jasonx_value +=1
    if event.type == pygame.QUIT:
        break
    key = pygame.key.get_pressed()
    if key[pygame.K_ESCAPE]:
        break

    M.setCamera((player_x,player_y), (window_width, window_height))
    player_x += 5
    if player_x >= 8800:
        player_x = 300
    window.fill((0, 0, 0))
    keylist = var[1]
    checks = var[2]
    var2 = var[3]
    if var[0]:
        calc.addkey(window)
        jasonx_value = 0
    M.draw(window)
    if var2:
        calc.fuckup(window)

    frame_counter += 1
    if frame_counter == 15:
        if me_vs_jason_2 == "still":
            me_vs_jason_2 = "step1"
        elif me_vs_jason_2 == "step1":
            me_vs_jason_2 = "step2"
        elif me_vs_jason_2 == "step2":
            me_vs_jason_2 = "still"
        frame_counter = 0

    frame_counter_a += 1
    if frame_counter_a == 10:
        if me_vs_jason_3 == "still_2":
            me_vs_jason_3 = "step1_2"
        elif me_vs_jason_3 == "step1_2":
            me_vs_jason_3 = "step2_2"
        elif me_vs_jason_3 == "step2_2":
            me_vs_jason_3 = "still_2"
        frame_counter_a = 0

    if me_vs_jason_2 == "still":
        window.blit(me_vs_jason, (jasonx_value, 300), (0, 0, 32, 32))
    elif me_vs_jason_2 == "step1":
        window.blit(me_vs_jason, (jasonx_value, 300), (32, 0, 32, 32))
    elif me_vs_jason_2 == "step2":
        window.blit(me_vs_jason, (jasonx_value, 300), (64, 0, 32, 32))

    if me_vs_jason_3 == "still_2":
        window.blit(me_vs_jason_4, (350, 300), (0, 32, 32, 32))
    elif me_vs_jason_3 == "step1_2":
        window.blit(me_vs_jason_4, (350, 300), (32, 32, 32, 32))
    elif me_vs_jason_3 == "step2_2":
        window.blit(me_vs_jason_4, (350, 300), (64, 32, 32, 32))
    window.blit(me_vs_jason, (150, 300), (0, 0, 0, 32))
    window.blit(me_vs_jason_4, (350, 300), (0, 32, 0, 64))

    if jasonx_value >= 350:
        break

    calc.write(window)

    pygame.display.update()
pygame.display.quit()
   

