#Title screen
import pygame
import random
import math

pygame.init()
pygame.font.init()

DS = pygame.display.set_mode((800,600))

game_state = 0

class Title(object):
    def __init__(self,surf):
        self.DS = surf
        """colors"""
        self.startBcolor = (255,151,47)
        self.exitBcolor = (255,151,47)
        self.creditsBcolor = (255,151,47)
        self.storyBcolor = (255,151,47)
        """fonts"""
        self.title_font = pygame.font.SysFont("Comic Sans",150)
        self.button_font = pygame.font.SysFont("Comic Sans",50)
        self.small_font = pygame.font.SysFont("Comic Sans",30)
        """images"""
        self.atc_hall = pygame.image.load("atc_hallway.jpg")
        self.fire = pygame.image.load("fire.png")
        #pygame.transform.scale(self.atc_hall,(800,600))
        
        self.color_angle = 0
    def draw(self):
        """color fluxuations"""
        self.color_angle += 5
        r_value = 200+50*math.sin(math.radians(self.color_angle))
        y_value = 50+50*math.sin(math.radians(self.color_angle))

        """image blit"""
        self.DS.blit(self.atc_hall,(0,0))
        
        """text render"""
        title = self.title_font.render("1803 HELL!",False,(r_value,y_value,0))
        warning = self.small_font.render("Enter at your own risk",False,(255,0,0))
        start_button = self.button_font.render("START",False,(255,0,0))
        exit_button = self.button_font.render("EXIT",False,(255,0,0))
        credits_button = self.button_font.render("CREDITS",False,(255,0,0))
        story_button = self.button_font.render("STORY",False,(255,0,0))

        """text blit"""
        self.DS.blit(self.fire,(160,-30))
        self.DS.blit(title,(130,130))
        self.DS.blit(warning,(285,500))

        """buttons"""
        pygame.draw.rect(self.DS,self.startBcolor,(300,300,200,50),0)
        pygame.draw.rect(self.DS,self.exitBcolor,(300,370,200,50),0)
        pygame.draw.rect(self.DS,self.creditsBcolor,(300,440,200,50),0)
        pygame.draw.rect(self.DS,(255,151,47),(275,495,250,2),0)
        pygame.draw.rect(self.DS,(255,151,47),(275,520,250,2),0)
        pygame.draw.circle(self.DS,self.storyBcolor,(670,400),70,0)
        self.DS.blit(start_button,(340,310))
        self.DS.blit(exit_button,(350,380))
        self.DS.blit(credits_button,(320,450))
        self.DS.blit(story_button,(610,385))


    def position_check(self,mouse_pos,buttonx,buttony,shape,radius=0):
        (MPx,MPy) = mouse_pos
        if shape == "rect":
            if MPy >= buttony and MPy <= buttony + 50 and MPx >= buttonx and MPx <= buttonx + 200:
                 return True
            else:
                return False

        if shape == "circle":
            if ((buttonx - MPx)**2 + (buttony - MPy)**2)**0.5 <= radius:
                return True
            else:
                return False
    

class Credits(object):
    def __init__(self,surf):
        self.DS = surf
        self.arrow_type = 0

        """fonts"""
        self.name_font = pygame.font.SysFont("Comic Sans",100)
        """images"""
        self.atc_hall = pygame.image.load("atc_hallway.jpg")
        self.arrow = pygame.image.load("arrow.png")
        self.hover_arrow = pygame.image.load("arrow_hover.png")

    def draw(self):

        """"text renders"""
        hayden = self.name_font.render("Hayden",False,(255,0,0))
        deme = self.name_font.render("Demetrius",False,(255,0,0))
        brady = self.name_font.render("Brady",False,(255,0,0))
        eric = self.name_font.render("Eric",False,(255,0,0))

        """image blit"""
        self.DS.blit(self.atc_hall,(0,0))
        if self.arrow_type == 0:
            self.DS.blit(self.arrow,(0,0))
        elif self.arrow_type == 1:
            self.DS.blit(self.hover_arrow,(0,0))

        """text blit"""
        self.DS.blit(hayden,(270,100))
        self.DS.blit(deme,(230,200))
        self.DS.blit(brady,(290,300))
        self.DS.blit(eric,(320,400))

        """designs stuff"""
        pygame.draw.rect(DS,(255,151,47),(270,170,260,5),0)
        pygame.draw.rect(DS,(255,151,47),(250,260,300,5),0)
        pygame.draw.rect(DS,(255,151,47),(270,370,260,5),0)
        pygame.draw.rect(DS,(255,151,47),(290,470,200,5),0)
        

    def position_check(self,mouse_pos,buttonx,buttony,shape,radius=0):
        (MPx,MPy) = mouse_pos
        if shape == "rect":
            if MPy >= buttony and MPy <= buttony + 100 and MPx >= buttonx and MPx <= buttonx + 100:
                 return True
            else:
                return False

        if shape == "circle":
            if ((buttonx - MPx)**2 + (buttony - MPy)**2)**0.5 <= radius:
                return True
            else:
                return False

class Story(object):
    def __init__(self,surf):
        self.DS = surf
        self.story_list = []
        self.color_angle = 0
        self.arrow_type = 0

        "text"
        self.story_font = pygame.font.SysFont("Comic Sans",30)
        self.story_font_large = pygame.font.SysFont("Comic Sans",100)

        """images"""
        self.atc_hall = pygame.image.load("atc_hallway.jpg")
        self.arrow = pygame.image.load("arrow.png")
        self.hover_arrow = pygame.image.load("arrow_hover.png")


    def draw(self):
        self.color_angle += 5
        r_value = 200+50*math.sin(math.radians(self.color_angle))
        y_value = 50+50*math.sin(math.radians(self.color_angle))

        """text render"""
        font_color = (0,0,255)
        storyP1 = self.story_font.render("It's just another normal day in Jason's 1803 concepts of 3D graphics class...",False,font_color)
        storyP2 = self.story_font.render("Jason seems to be a bit late today... which is not normal...",False,font_color)
        storyP3 = self.story_font.render("You're just sitting in class waiting for him and wondering what",False,font_color)
        storyP3_2 = self.story_font.render("could be on today's agenda...",False,font_color)
        storyP4 = self.story_font.render("SUDDENLY, JASON BURSTS THROUGH THE DOOR!",False,font_color)
        storyP5 = self.story_font.render("He yells, 'EXAM TIME!' and walks in...",False,font_color)
        storyP6 = self.story_font.render("Oh no! You forgot about the exam!!!",False,font_color)
        storyP7 = self.story_font.render("Wait, what is he holding? A KATANA?! AND HE'S COMING STRAIGHT FOR YOU!",False,font_color)
        storyP8 = self.story_font_large.render("RUN!!!!!!!!",False,(r_value,y_value,0))
        
        """image blit"""
        self.DS.blit(self.atc_hall,(0,0))
        if self.arrow_type == 0:
            self.DS.blit(self.arrow,(0,0))
        elif self.arrow_type == 1:
            self.DS.blit(self.hover_arrow,(0,0))

        """text blit"""
        pygame.draw.rect(self.DS,(255,151,47),(0,110,800,220),0)
        self.DS.blit(storyP1,(30,110))
        self.DS.blit(storyP2,(100,140))
        self.DS.blit(storyP3,(80,170))
        self.DS.blit(storyP3_2,(280,190))
        self.DS.blit(storyP4,(170,220))
        self.DS.blit(storyP5,(230,250))
        self.DS.blit(storyP6,(230,280))
        self.DS.blit(storyP7,(0,310))
        self.DS.blit(storyP8,(250,410))

    def position_check(self,mouse_pos,buttonx,buttony,shape,radius=0):
        (MPx,MPy) = mouse_pos
        if shape == "rect":
            if MPy >= buttony and MPy <= buttony + 100 and MPx >= buttonx and MPx <= buttonx + 100:
                 return True
            else:
                return False

        if shape == "circle":
            if ((buttonx - MPx)**2 + (buttony - MPy)**2)**0.5 <= radius:
                return True
            else:
                return False

        
class Game_Over(object):
    def __init__(self,surf):
        self.DS = surf
        self.color_angle = 0
        self.menuBcolor = (255,151,47)
        self.exitBcolor= (255,151,47)

        """images"""
        self.atc_hall = pygame.image.load("atc_hallway.jpg")
        self.death = pygame.image.load("dead.png")

        """text"""
        self.game_over_text = pygame.font.SysFont("Comic Sans",190)
        self.button_font = pygame.font.SysFont("Comic Sans",50)
        
    def draw(self):
        self.color_angle += 5
        r_value = 200+50*math.sin(math.radians(self.color_angle))
        y_value = 50+50*math.sin(math.radians(self.color_angle))
        
        """text renders"""       
        gameover = self.game_over_text.render("GAME OVER",False,(r_value,y_value,0))
        menu = self.button_font.render("MENU",False,(255,0,0))
        exitbutton = self.button_font.render("EXIT",False,(255,0,0))

        """image blits"""
        self.DS.blit(self.atc_hall,(0,0))
        self.DS.blit(self.death,(335,200))

        """buttons"""
        pygame.draw.rect(self.DS,self.menuBcolor,(300,430,200,50),0)
        pygame.draw.rect(self.DS,self.exitBcolor,(300,500,200,50),0)

        """text blits"""
        self.DS.blit(gameover,(0,0))
        self.DS.blit(menu,(350,435))
        self.DS.blit(exitbutton,(350,505))


    def position_check(self,mouse_pos,buttonx,buttony,shape,radius=0):
        (MPx,MPy) = mouse_pos
        if shape == "rect":
            if MPy >= buttony and MPy <= buttony + 50 and MPx >= buttonx and MPx <= buttonx + 200:
                 return True
            else:
                return False

        if shape == "circle":
            if ((buttonx - MPx)**2 + (buttony - MPy)**2)**0.5 <= radius:
                return True
            else:
                return False
        
        
clock = pygame.time.Clock()
title = Title(DS)
creditscreen = Credits(DS)
story = Story(DS)
gameover = Game_Over(DS)
while True:
    """main title"""
    while game_state == 0:
        clock.tick(60)
        
        """variables for whole loop"""
        mousePos = pygame.mouse.get_pos()
        (mouseL,mouseR,mouseM) = pygame.mouse.get_pressed()

        """drawing"""
        title.draw()

        """button checks"""
        start_hover = title.position_check(mousePos,300,300,"rect")
        exit_hover = title.position_check(mousePos,300,370,"rect")
        credits_hover = title.position_check(mousePos,300,440,"rect")
        story_hover = title.position_check(mousePos,670,400,"circle",70)
        #print(exit_hover)
        #print(start_hover)
        #print(credits_hover)
        #print(story_hover)
        
        if start_hover == True:
             title.startBcolor = (0,0,255)
             if mouseL == True:
                 game_state = 4
        else:
            title.startBcolor = (255,151,47)

        if exit_hover == True:
             title.exitBcolor = (0,0,255)
             if mouseL == True:
                game_state = -1
        else:
            title.exitBcolor = (255,151,47)

        if credits_hover == True:
             title.creditsBcolor = (0,0,255)
             if mouseL == True:
                game_state = 1
        else:
            title.creditsBcolor = (255,151,47)

        if story_hover == True:
             title.storyBcolor = (0,0,255)
             if mouseL == True:
                game_state = 2
        else:
            title.storyBcolor = (255,151,47)



        """quiting the loop stuff"""
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            game_state = -1
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state = -1

        pygame.display.update()

    """"credits"""
    while game_state == 1:
        clock.tick(60)

        """varables for while loop"""
        mousePos = pygame.mouse.get_pos()
        (mouseL,mouseR,mouseM) = pygame.mouse.get_pressed()


        """drawing"""
        creditscreen.draw()

        """button checks"""
        back_hover = creditscreen.position_check(mousePos,0,0,"rect")

        if back_hover == True:
             creditscreen.arrow_type = 1
             if mouseL == True:
                 game_state = 0
        else:
            creditscreen.arrow_type = 0
        
        """quiting the loop stuff"""
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            game_state = -1
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state = -1

        pygame.display.update()

    """story"""
    while game_state == 2:
        clock.tick(60)
        
        """varables for while loop"""
        mousePos = pygame.mouse.get_pos()
        (mouseL,mouseR,mouseM) = pygame.mouse.get_pressed()

        """drawing"""
        story.draw()

        """button checks"""
        back_hover = story.position_check(mousePos,0,0,"rect")

        if back_hover == True:
             story.arrow_type = 1
             if mouseL == True:
                 game_state = 0
        else:
            story.arrow_type = 0

        """quiting the loop stuff"""
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            game_state = -1
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state = -1

        pygame.display.update()

    while game_state == 5:
        clock.tick(60)
        
        """varables for while loop"""
        mousePos = pygame.mouse.get_pos()
        (mouseL,mouseR,mouseM) = pygame.mouse.get_pressed()

        """drawing"""
        gameover.draw()

        """button checks"""
        menu_hover = gameover.position_check(mousePos,300,430,"rect")
        exit_hover = gameover.position_check(mousePos,300,500,"rect")
        
        if menu_hover == True:
             gameover.menuBcolor = (0,0,255)
             if mouseL == True:
                game_state = 0
        else:
            gameover.menuBcolor = (255,151,47)

        if exit_hover == True:
             gameover.exitBcolor = (0,0,255)
             if mouseL == True:
                game_state = -1
        else:
            gameover.exitBcolor = (255,151,47)

        """quiting the loop stuff"""
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            game_state = -1
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_state = -1

        pygame.display.update()

    """ultimate kill switch"""
    if game_state == -1 or game_state == 4:
        pygame.display.quit()
        break
