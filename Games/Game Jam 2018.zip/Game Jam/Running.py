import pygame
import time
import random
pygame.init()

def DrawJason(screen,x,y):
    pygame.draw.circle(screen,(255,50,200),(x,y),20,0)


class keys:
    def __init__(self):
        self.possible = [pygame.K_0,pygame.K_1,pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7,
                         pygame.K_8, pygame.K_9, pygame.K_SEMICOLON, pygame.K_LEFTBRACKET, pygame.K_RIGHTBRACKET, pygame.K_a,pygame.K_b,
                         pygame.K_c, pygame.K_d, pygame.K_e, pygame.K_f, pygame.K_q, pygame.K_w, pygame.K_r, pygame.K_t, pygame.K_y, pygame.K_u, pygame.K_i,
                         pygame.K_o, pygame.K_p, pygame.K_s, pygame.K_g, pygame.K_h, pygame.K_j, pygame.K_k, pygame.K_l, pygame.K_z,
                         pygame.K_x, pygame.K_v, pygame.K_n, pygame.K_m,pygame.K_KP0, pygame.K_KP1, pygame.K_KP2, pygame.K_KP3, pygame.K_KP4, pygame.K_KP5, pygame.K_KP6, pygame.K_KP7, pygame.K_KP8, pygame.K_KP9]
        self.names = ["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Semicolon","Left Bracket",
                      "Right Bracket", "A","B","C","D","E","F","Q","W","R","T","Y","U","I","O","P","S","G","H","J","K","L","Z","X","V","N",
                      "M","Keypad Zero","Keypad One","Keypad Two","Keypad Three","Keypad Four","Keypad Five",
                      "Keypad Six","Keypad Seven","Keypad Eight","Keypad Nine"]
        self.temp = "Space"
        self.keys = [pygame.K_SPACE]
    def addkey(self,screen):
        rand = random.randint(0,len(self.possible)-1)
        self.keys.append(self.possible[rand])
        self.temp = self.names[rand]

    def write(self,screen):
        font = pygame.font.SysFont("Comic Sans", 50)
        surf = font.render("your new key is " + self.temp, True, (0, 0,0))
        screen.blit(surf, (210, 50))
    def fuckup(self,screen):
        font = pygame.font.SysFont("Comic Sans", 50)
        surf = font.render("Retry Sequence", True, (0, 255,255))
        screen.blit(surf, (265, 100))

    def checkpat(self,screen,checks,list,var2):
        var = False
        for i in range(0, len(list)):
            if list[i] != self.keys[i]:
                list = []
                var2 = True

        if len(list) == len(self.keys):
            for i in range(0,len(list)):
                if checks == len(self.keys):
                    var = True
                    var2 = False
                    checks = 0
                    list.clear()
                    break
                if list[i] == self.keys[i]:
                    checks += 1
                    continue
                elif list[i] != self.keys[i]:
                    list.clear()
                    checks = 0
                    var2 = True
                    break

        return (var,list,checks,var2)





if __name__ == "__main__":
    clock = pygame.time.Clock()
    screen = pygame.display.set_mode((800,600))
    test = keys()
    list2 = [pygame.K_SPACE]
    jasonx= 0
    list = []
    jasonx = 0
    checks = 0
    while True:
        evt = pygame.event.poll()
        pygame.event.pump()
        if evt.type == pygame.KEYDOWN:
            list.append(evt.key)
        var = test.checkpat(screen,checks,list)
        checks = 0
        jasonx += 1
        clock.tick(30)
        screen.fill((0,0,0))
        DrawJason(screen, jasonx, 400)
        test.write(screen)
        list = var[1]
        checks = var[2]
        if var[0]:
            test.addkey(screen)
            jasonx = 0
        pygame.display.update()

        # test.addkey()
        # print(test.keys)












