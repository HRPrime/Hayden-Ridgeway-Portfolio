"""main loop"""
import pygame
import math
import random
import titlescreen as title

game_state = True
game_part = 0

while game_state:
    while game_part == 0:
        
        print(game_part)
        if title.game_state == -1:
            game_state = False

        if title.game_state == 4:
            game_part = 1


        if game_part == 1:
            import maingame
            game_part = 0
            

            
            title.game_state == 1
            


    
