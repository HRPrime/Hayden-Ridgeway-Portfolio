

import pygame
import random

class Map:
    def __init__(self, fname):
        self.tile_width = None              # Width of each tile (in pixels)
        self.tile_height = None             # Height of each tile (in pixels)
        self.map_width = None               # Width of map (in tiles)
        self.map_height = None              # Height of map (in tiles)
        self.mTileImage = None              # Pygame surface containing all tiles in this map
        self.mTileOffsetX = None            # Number of pixels between each tile horizontally in self.mTileImage
        self.mTileOffsetY = None            # Number of pixels between each tile vertically in self.mTileImage
        self.mTileImageNumX = None          # Number of tiles horizontally in self.mTileImage (I naively assume this is the number of tiles self.tile_width goes into the widht of the image
        self.mTileImageNumY = None          # Number of tiles horizontally in self.mTileImage
        self.mTileCodes = []                # Will become a 2d list of tile-codes (I'm currently only supporting one tile layer)
        self.mCamera = [0, 0]
        self.loadFlare(fname)


        self.mPlayer = None
        self.mFName = fname                 # The filename this map was loaded from.
        self.mCoins = []                    # A list of tile-coordinates containing coins
        self.mCoinImage = None


    def get_tile_dimensions(self):
        return (self.tile_width, self.tile_height)



    def setCamera(self, cpos, screen_dim):
        maxi = [self.map_width * self.tile_width - screen_dim[0], self.map_height * self.tile_height - screen_dim[1]]
        for i in range(2):
            self.mCamera[i] = cpos[i]
            if self.mCamera[i] < 0:
                self.mCamera[i] = 0
            if self.mCamera[i] > maxi[i]:
                self.mCamera[i] = maxi[i]




    def loadFlare(self, fname):
        section = None
        fp = open(fname, "r")
        for line in fp:
            line = line.strip()
            if len(line) == 0:
                continue

            if len(line) > 2 and line[0] == "[" and line[-1] == "]":
                section = line[1:-1]
            elif section == "header" and line.count("=") == 1:
                parts = line.split("=")
                parts[0] = parts[0].strip()
                if parts[0] == "width":         self.map_width = int(parts[1])
                elif parts[0] == "height":      self.map_height = int(parts[1])
                elif parts[0] == "tilewidth":   self.tile_width = int(parts[1])
                elif parts[0] == "tileheight":  self.tile_height = int(parts[1])
            elif section == "tilesets" and line.count("=") == 1:
                image_info = line.split("=")[1]
                img_fname, tile_w, tile_h, offset_x, offset_y = image_info.split(",")
                self.mTileOffsetX = int(offset_x)
                self.mTileOffsetY = int(offset_y)
                self.mTileImage = pygame.image.load(img_fname)
                self.mTileImageNumX = self.mTileImage.get_width() // (self.tile_width + self.mTileOffsetX)
                self.mTileImageNumY = self.mTileImage.get_height() // (self.tile_height + self.mTileOffsetY)
            elif section == "layer":
                if line.count(",") >= self.map_width - 1:
                    codes = line.split(",")
                    if len(codes) > self.map_width:
                        codes = codes[:-1]
                    row = []
                    for c in codes:
                        row.append(int(c))
                    self.mTileCodes.append(row)

    def __str__(self):
        s = ""
        s += "self.tile_width = " + str(self.tile_width) + "\n"
        s += "self.tile_height = " + str(self.tile_height) + "\n"
        s += "self.map_width = " + str(self.map_width) + "\n"
        s += "self.map_height = " + str(self.map_height) + "\n"
        s += "self.mTileImage = " + str(self.mTileImage) + "\n"
        s += "self.mTileOffsetX = " + str(self.mTileOffsetX) + "\n"
        s += "self.mTileOffsetY = " + str(self.mTileOffsetY) + "\n"
        s += "self.mTileImageNumX = " + str(self.mTileImageNumX) + "\n"
        s += "self.mTileImageNumY = " + str(self.mTileImageNumY) + "\n"
        s += "self.mTileCodes =\n"
        for row in self.mTileCodes:
            s += "   " + str(row) + "\n"
        return s


    def draw(self, surf):

        for layer_num in range(0, len(self.mTileCodes)):
            offsetx = int(self.mCamera[0]) % self.tile_width
            offsety = int(self.mCamera[1]) % self.tile_height
            sx = int(self.mCamera[0]) // self.tile_width  # screen x
            sy = int(self.mCamera[1]) // self.tile_height  # screen y
            sw = surf.get_width() // self.tile_width + 2  # screen width
            sh = surf.get_height() // self.tile_height + 2  # screen height
            y = -offsety

            for i in range(sy, sy + sh):
                if i < 0 or i >= self.map_height:
                    continue
                row = self.mTileCodes[layer_num][i]

        # Draw the map (only the portion we need)
        offsetx = int(self.mCamera[0]) % self.tile_width
        offsety = int(self.mCamera[1]) % self.tile_height
        sx = int(self.mCamera[0]) // self.tile_width
        sy = int(self.mCamera[1]) // self.tile_height
        sw = surf.get_width() // self.tile_width
        sh = surf.get_height() // self.tile_height
        y = -offsety
        #y = 0
        for row_num in range(sy, sy + sh+1):
            row = self.mTileCodes[row_num]
            x = -offsetx
            #x = 0
            for col_num in range(sx, sx + sw +1):
                code = row[col_num]
                if code != 0:
                    tile_row = (code - 1) // self.mTileImageNumX
                    tile_col = (code - 1) % self.mTileImageNumX
                    tile_x = tile_col * (self.tile_width + self.mTileOffsetX)
                    tile_y = tile_row * (self.tile_height + self.mTileOffsetY)
                    surf.blit(self.mTileImage, (x, y), (tile_x, tile_y, self.tile_width, self.tile_height))
                x += self.tile_width
            y += self.tile_height


    def get_screen_pos(self, wx, wy):
        return (wx - self.mCamera[0], wy - self.mCamera[1])


